/*
 * File:   
 * Author: <NAME>
 *
 * Created on 1 December, 2023, 10:40 AM
 */


#include <xc.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include "eeprom.h"
#include "matrix_keypad.h"

inti_config()
{
    //
}

void main(void) {
    inti_config();
    
    char main_f = 0, menu_f = 0,key;
    
    while (1)
    {
        /*
         * get the time 
         * based on switch press change the event
         */
        
        if(main_f == DASHBOARD)
        {
            dashboard();
        }
        else if(main_f == PASSWORD)
        {
            password(key);
        }
        else if(main_f == MENU)
        {
            menu(key);
        }
        else if(main_f == MENU_ENTER)
        {
            if(menu_f == VIEWLOG)
            {
                view_log(key);
            }
            else if(menu_f == DOWNLOADLOG)
            {
                download_log();
            }
            else if(menu_f == CLEARLOG)
            {
                clear_log(key);
            }
            else if(menu_f == SETTIME)
            {
                settime(key);
            }
            else if(menu_f == CHANGEPASS)
            {
                change_pass(key);
            }
        }
        
    }
    return;
}
